# DisEarn deployment hand-off

## What is now connected in the source
- Native Compose app: create account, sign in, persist session, show registration fee, start Paystack/Flutterwave checkout, check payment status, browse tasks, submit proof, view wallet transactions, request withdrawals, view referrals and browse skills.
- API: authentication, task/submission, skills, wallet/withdrawal, referral, payment initialization, provider webhook verification and admin operations.
- Admin dashboard: user/task/submission/withdrawal/skills/wallet management and editable fee, currency, enabled gateways, referral percentage and encrypted gateway-secret rotation.
- Referral rule: 30% default; inviter commission is posted once only after the referred user's payment has been verified by the provider.

## What must be supplied by the owner
1. A hosting account and domain with HTTPS. No hosting account, DNS access or deployment credentials were provided, so this project has not been deployed publicly.
2. Paystack and/or Flutterwave merchant accounts and their secret keys. Enter the keys only in the admin settings after deployment.
3. The administrator password as an environment secret. The admin email is prefilled in `.env.example`; set the password in the host's secret manager or private `backend/.env`. Do not put it in this ZIP, Git, Android, or screenshots.
4. A secure generated `JWT_SECRET` and `PAYMENT_ENCRYPTION_KEY` (generation commands are in `ADMIN-SETUP.txt`). Back up the encryption key securely.

## Deploy backend
- Provision a persistent-volume Docker host or VPS. Build `backend/Dockerfile`, expose port 8080 behind an HTTPS reverse proxy, and mount persistent storage at `/app/data`.
- Set `DB_PATH=/app/data/disearn.db`, `PORT=8080`, `NODE_ENV=production`, `APP_BASE_URL=https://YOUR-API-DOMAIN`, `ADMIN_EMAIL`, `ADMIN_PASSWORD`, `JWT_SECRET`, `PAYMENT_ENCRYPTION_KEY`, and `TRUST_PROXY=true` only if a trusted reverse proxy is in front.
- Do not expose the raw Node port publicly when relying on a reverse proxy. Configure backups for the SQLite database and keep secrets outside the image.
- Verify `https://YOUR-API-DOMAIN/api/health`, then open `/admin` and sign in.

## Payment setup
- In admin settings, configure the fee, currency, enabled gateway(s), 30% referral rate and provider secret keys.
- Register webhooks with the provider: `/api/webhooks/paystack` and `/api/webhooks/flutterwave` on the same HTTPS API origin.
- Use provider test-mode keys and test transactions first. Confirm webhook delivery, currency, amount, settlement and a single referral ledger credit. Use only currencies supported by the merchant account and selected provider.
- Withdrawals are reviewed manually by the administrator; approving a withdrawal must happen only after the payout is actually sent. No automatic bank payout integration is included.

## Build Android app
- Open `android/` in Android Studio with Android SDK 35 and a compatible JDK/Gradle toolchain.
- Edit `android/gradle.properties`: set `DISearn_API_URL=https://YOUR-API-DOMAIN/`.
- Sync Gradle, run on a physical Android device, and test registration, checkout return, payment status, task proof, wallet, referrals and withdrawal request.
- Create and securely store your own release signing key, then build a signed APK/AAB from Android Studio. This package is source code; it does not contain a signed APK.

## Release gates
Before real users or real funds: test all payment webhooks, test duplicate/replayed callbacks, confirm ledger reconciliation, add privacy policy/terms and support channels, configure monitoring and backups, verify provider country/currency availability, and obtain an independent security/compliance review. A live production deployment cannot be completed without the owner's hosting, DNS and merchant-account access.
