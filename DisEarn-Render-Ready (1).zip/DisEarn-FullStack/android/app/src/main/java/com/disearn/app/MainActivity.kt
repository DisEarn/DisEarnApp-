package com.disearn.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.disearn.app.data.*
import kotlinx.coroutines.launch
import retrofit2.HttpException
import java.util.Locale

private val Navy = Color(0xFF101A2E)
private val Panel = Color(0xFF202D43)
private val Muted = Color(0xFFAAB7CA)
private val Aqua = Color(0xFF20C8D0)
private val Green = Color(0xFF0DBB8B)

class MainActivity : ComponentActivity() {
    private val api by lazy { DisEarnApiFactory.create(BuildConfig.DISearn_API_URL) }
    private val prefs by lazy { getSharedPreferences("disearn", MODE_PRIVATE) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DisEarnApp(api, prefs.getString("token", null), { token -> prefs.edit().putString("token", token).apply() }, { prefs.edit().remove("token").apply() }, { url -> startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }) }
    }
}

@Composable
fun DisEarnApp(api: DisEarnApi, savedToken: String?, saveToken: (String) -> Unit, clearToken: () -> Unit, openUrl: (String) -> Unit) {
    var token by remember { mutableStateOf(savedToken) }
    var user by remember { mutableStateOf<AuthUser?>(null) }
    var page by remember { mutableStateOf("Home") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val bearer = "Bearer ${token.orEmpty()}"
    suspend fun refreshUser() { if (!token.isNullOrBlank()) user = api.me(bearer) }
    LaunchedEffect(token) { if (!token.isNullOrBlank()) runCatching { refreshUser() }.onFailure { message = errorText(it); if (it is HttpException && it.code() == 401) { token = null; clearToken() } } }
    MaterialTheme(colorScheme = darkColorScheme(background = Navy, surface = Panel, primary = Aqua)) {
        Scaffold(containerColor = Navy, bottomBar = { if (token != null && user?.paymentStatus == "paid") NavigationBar(containerColor = Color(0xFF17243A)) {
            listOf("Home" to Icons.Default.Home, "Tasks" to Icons.Default.TaskAlt, "Wallet" to Icons.Default.AccountBalanceWallet, "Referrals" to Icons.Default.CardGiftcard, "Skills" to Icons.Default.MenuBook).forEach { (label, icon) ->
                NavigationBarItem(selected = page == label, onClick = { page = label; message = "" }, icon = { Icon(icon, null) }, label = { Text(label) })
            }
        } }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) { Text("DIS", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold); Spacer(Modifier.width(8.dp)); Text("Digital Income System", color = Muted); Spacer(Modifier.weight(1f)); if (token != null) TextButton(onClick = { token = null; user = null; clearToken() }) { Text("Sign out") } }
                if (message.isNotBlank()) Text(message, color = Color(0xFFFFB4AB), modifier = Modifier.padding(vertical = 8.dp))
                when {
                    token == null -> AuthScreen(busy, { name, email, password, referral, register ->
                        scope.launch { busy = true; message = ""; try { val result = if (register) api.register(RegisterRequest(name, email, password, referral.ifBlank { null })) else api.login(LoginRequest(email, password)); token = result.token; saveToken(result.token); user = result.user; page = "Home" } catch (e: Exception) { message = errorText(e) } finally { busy = false } }
                    })
                    user == null -> LoadingScreen()
                    user?.paymentStatus != "paid" -> PaymentScreen(api, bearer, user!!, busy, { busy = it }, { message = it }, openUrl, { user = api.me(bearer) })
                    else -> when (page) {
                        "Tasks" -> TasksScreen(api, bearer, { message = it })
                        "Wallet" -> WalletScreen(api, bearer, { message = it })
                        "Referrals" -> ReferralsScreen(api, bearer)
                        "Skills" -> SkillsScreen(api, bearer)
                        else -> HomeDashboard(user!!, api, bearer, { page = it })
                    }
                }
            }
        }
    }
}

@Composable fun AuthScreen(busy: Boolean, onSubmit: (String,String,String,String,Boolean)->Unit) {
    var register by remember { mutableStateOf(false) }; var name by remember { mutableStateOf("") }; var email by remember { mutableStateOf("") }; var password by remember { mutableStateOf("") }; var referral by remember { mutableStateOf("") }
    Column(Modifier.fillMaxWidth().padding(top = 40.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(if (register) "Create your DisEarn account" else "Welcome back", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Text("Sign in to access tasks, learning resources and rewards.", color = Muted)
        if (register) Field("Full name", name) { name = it }
        Field("Email address", email) { email = it }
        Field("Password (minimum 10 characters)", password) { password = it }
        if (register) Field("Referral code (optional)", referral) { referral = it }
        Button(onClick = { onSubmit(name,email,password,referral,register) }, enabled = !busy && email.isNotBlank() && password.length >= 10 && (!register || name.isNotBlank()), modifier = Modifier.fillMaxWidth().height(52.dp)) { Text(if (busy) "Please wait…" else if (register) "Create account" else "Sign in") }
        TextButton(onClick = { register = !register }) { Text(if (register) "Already have an account? Sign in" else "New to DisEarn? Create an account") }
    }
}
@Composable fun Field(label: String, value: String, onValue: (String)->Unit) { OutlinedTextField(value,onValue,label={Text(label)},modifier=Modifier.fillMaxWidth(),singleLine=true) }

@Composable fun PaymentScreen(api: DisEarnApi, bearer: String, user: AuthUser, busy: Boolean, setBusy: (Boolean)->Unit, setMessage: (String)->Unit, openUrl: (String)->Unit, onPaid: suspend ()->Unit) {
    var settings by remember { mutableStateOf<PaymentSettings?>(null) }; var provider by remember { mutableStateOf("paystack") }; var reference by remember { mutableStateOf("") }; val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) { runCatching { settings = api.paymentSettings(bearer); provider = if (settings?.gateway == "flutterwave") "flutterwave" else "paystack" }.onFailure { setMessage(errorText(it)) } }
    Column(Modifier.fillMaxWidth().padding(top=36.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) {
        Text("Complete registration", color=Color.White,fontSize=27.sp,fontWeight=FontWeight.Bold)
        Text("Your account is created. Complete the registration payment to unlock DisEarn.",color=Muted)
        Card(colors=CardDefaults.cardColors(containerColor=Panel)) { Column(Modifier.padding(20.dp)) { Text("Registration fee",color=Muted); Text(settings?.let { money(it.registrationFee,it.currency) } ?: "Loading fee…",color=Color.White,fontSize=30.sp,fontWeight=FontWeight.Bold); Text("Referral rewards are credited only after verified successful payment.",color=Muted) } }
        if (settings?.gateway == "both") Row { FilterChip(provider=="paystack",{provider="paystack"},label={Text("Paystack")}); Spacer(Modifier.width(8.dp)); FilterChip(provider=="flutterwave",{provider="flutterwave"},label={Text("Flutterwave")}) }
        Button(enabled=!busy && settings!=null, onClick={scope.launch { setBusy(true); try { val p=api.initializePayment(bearer,PaymentInitRequest(provider)); if(p.paid) setMessage("Registration is already paid.") else { reference=p.reference.orEmpty(); p.checkoutUrl?.let(openUrl) ?: setMessage("Checkout link was not returned.") } } catch(e:Exception){setMessage(errorText(e))} finally{setBusy(false)} } },modifier=Modifier.fillMaxWidth().height(52.dp)) { Text(if(busy) "Preparing checkout…" else "Pay registration fee") }
        if(reference.isNotBlank()) OutlinedButton(onClick={ scope.launch { setBusy(true); try { val p=api.paymentStatus(bearer,reference); setMessage(if(p.status=="paid") { onPaid(); "Payment confirmed. Your account is now active." } else "Payment status: ${p.status}. It may take a moment for the provider webhook to confirm.") } catch(e:Exception){setMessage(errorText(e))} finally{setBusy(false)} } },modifier=Modifier.fillMaxWidth()) { Text("Check payment status") }
    }
}
@Composable fun HomeDashboard(user: AuthUser, api: DisEarnApi, bearer: String, go: (String)->Unit) {
    Column(Modifier.fillMaxSize().padding(top=28.dp), verticalArrangement=Arrangement.spacedBy(16.dp)) {
        Text("Hello, ${user.name}",color=Color.White,fontSize=28.sp,fontWeight=FontWeight.Bold); Text("Your DisEarn dashboard",color=Muted)
        listOf("Tasks" to "Explore activities and submit proof.","Wallet" to "View your balance and transactions.","Referrals" to "Share your code and track eligible referrals.","Skills" to "Learn useful digital skills.").forEach { (title,body) -> Card(onClick={go(title)},colors=CardDefaults.cardColors(containerColor=Panel),modifier=Modifier.fillMaxWidth()) { Column(Modifier.padding(20.dp)) { Text(title,color=Aqua,fontSize=19.sp,fontWeight=FontWeight.Bold); Text(body,color=Muted) } } }
        Text("Your referral code: ${user.referralCode}",color=Color.White)
    }
}
@Composable fun TasksScreen(api: DisEarnApi,bearer:String,setMessage:(String)->Unit) { var tasks by remember { mutableStateOf<List<TaskItem>>(emptyList()) }; val scope= rememberCoroutineScope(); LaunchedEffect(Unit){runCatching{tasks=api.tasks(bearer)}.onFailure{setMessage(errorText(it))}}; LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){items(tasks){t->Card(colors=CardDefaults.cardColors(containerColor=Panel)){Column(Modifier.padding(16.dp)){Text(t.title,color=Color.White,fontWeight=FontWeight.Bold,fontSize=18.sp);Text("${t.platform} • ${t.reward}",color=Aqua);Text(t.description,color=Muted);if(t.instructions.isNotBlank())Text(t.instructions,color=Muted);var proof by remember{mutableStateOf("")};Field("Proof URL or details",proof){proof=it};Button(enabled=proof.isNotBlank(),onClick={scope.launch{runCatching{api.submitTask(bearer,t.id,SubmissionRequest(proof));setMessage("Task submitted for review.")}.onFailure{setMessage(errorText(it))}}}){Text("Submit proof")}}}}} }
@Composable fun WalletScreen(api:DisEarnApi,bearer:String,setMessage:(String)->Unit){
    var wallet by remember{mutableStateOf<WalletResponse?>(null)}
    var amount by remember{mutableStateOf("")}; var method by remember{mutableStateOf("Bank transfer")}; var destination by remember{mutableStateOf("")}; var busy by remember{mutableStateOf(false)}
    val scope= rememberCoroutineScope()
    LaunchedEffect(Unit){runCatching{wallet=api.wallet(bearer)}.onFailure{setMessage(errorText(it))}}
    LazyColumn(verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item { Text("Wallet balance",color=Muted); Text(wallet?.let{String.format(Locale.US,"%.2f",it.balance)}?:"Loading…",color=Color.White,fontSize=32.sp,fontWeight=FontWeight.Bold) }
        item { Text("Request a withdrawal",color=Color.White,fontSize=20.sp,fontWeight=FontWeight.Bold); Field("Amount",amount){amount=it}; Field("Payout method",method){method=it}; Field("Account / wallet destination",destination){destination=it}; Button(enabled=!busy && amount.toDoubleOrNull()?.let{it>0}==true && destination.isNotBlank(),onClick={scope.launch{busy=true;runCatching{api.withdraw(bearer,WithdrawalRequest(amount.toDouble(),method,destination));setMessage("Withdrawal request submitted for admin review.");wallet=api.wallet(bearer);amount="";destination=""}.onFailure{setMessage(errorText(it))};busy=false}}){Text(if(busy)"Submitting…" else "Request withdrawal")} }
        item { Text("Recent transactions",color=Color.White,fontSize=20.sp,fontWeight=FontWeight.Bold) }
        items(wallet?.transactions?:emptyList()) { t -> Card(colors=CardDefaults.cardColors(containerColor=Panel),modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp)){Text(t.description,color=Color.White);Text("${t.amount} • ${t.created_at}",color=Muted)}} }
    }
}
@Composable fun ReferralsScreen(api:DisEarnApi,bearer:String){var data by remember{mutableStateOf<ReferralResponse?>(null)};LaunchedEffect(Unit){runCatching{data=api.referrals(bearer)}};Column(verticalArrangement=Arrangement.spacedBy(10.dp)){Text("Referral programme",color=Color.White,fontSize=24.sp,fontWeight=FontWeight.Bold);Text("Your code: ${data?.referralCode?:"Loading…"}",color=Aqua);Text("Commission earned: ${data?.commissionEarned?:0.0}",color=Color.White);data?.referrals?.forEach{Text("${it.name} • ${it.payment_status}",color=Muted)}}}
@Composable fun SkillsScreen(api:DisEarnApi,bearer:String){var skills by remember{mutableStateOf<List<SkillItem>>(emptyList())};LaunchedEffect(Unit){runCatching{skills=api.skills(bearer)}};LazyColumn{items(skills){s->Card(Modifier.fillMaxWidth().padding(bottom=8.dp),colors=CardDefaults.cardColors(containerColor=Panel)){Column(Modifier.padding(16.dp)){Text(s.title,color=Color.White,fontWeight=FontWeight.Bold);Text(s.description,color=Muted);Text(s.content_url,color=Aqua)}}}}}
@Composable fun LoadingScreen(){Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){CircularProgressIndicator(color=Aqua)}}
fun money(amount:Double,currency:String)=String.format(Locale.US,"%s %,.2f",currency,amount)
fun errorText(e:Throwable):String=when(e){is HttpException->"Request failed (${e.code()}): ${e.response()?.errorBody()?.string()?.take(300)?:e.message()}";else->e.message?:"Something went wrong."}
