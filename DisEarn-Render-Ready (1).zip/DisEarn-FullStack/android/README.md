# DisEarn Native Android (Kotlin + Jetpack Compose)

This is a native Android starter rebuild based on the supplied DisEarn APK and screenshots. It uses Kotlin and Jetpack Compose; it does **not** display a website in a WebView.

## Build
1. Install Android Studio (current stable) with Android SDK Platform 35.
2. Open this folder (`DisEarn-Native`) in Android Studio.
3. Allow Gradle sync to download the Android Gradle Plugin and dependencies.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Install the resulting `app/build/outputs/apk/debug/app-debug.apk` on your Android device.

## Important scope and limitations
- The supplied APK is a Flutter application and contains Flutter's native runtime plus an InAppWebView plugin. Its original Dart source code and backend implementation are not included in the APK, and cannot be faithfully recovered from the compiled package alone.
- This project is a fresh native Kotlin/Compose implementation of the visible screens and navigation, not a source-code conversion or a byte-for-byte clone.
- The screenshots show social media task categories, a Skills Library, and an advertised 30% referral commission. They do not reveal the backend APIs, real task workflow, account system, payment rules, or withdrawal implementation. Those require the original developer's source/API access and must be integrated before real earning or payment features can work.
- The project source is provided here; a compiled installable APK is not included because this environment has no Android SDK/Gradle build installation. Build it with Android Studio using the steps above.
