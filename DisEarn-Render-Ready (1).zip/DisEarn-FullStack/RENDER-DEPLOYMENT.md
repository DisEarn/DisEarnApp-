# DisEarn — Render deployment

This repository includes a Render Blueprint (`render.yaml`) for the Node.js API and admin dashboard.

## Important hosting notes
- The API uses SQLite. The Blueprint attaches a persistent disk at `/app/data`; do not remove it or user, wallet, payment, and referral records will be lost on redeploy/restart.
- Render persistent disks require a paid web-service plan. The Blueprint uses the `starter` plan and a 1 GB disk.
- The service is configured for Frankfurt and exposes `/api/health` as its health check.
- Render supplies `RENDER_EXTERNAL_URL`; the API uses it as a fallback for payment return URLs.

## Deploy
1. Push the contents of this project folder to a GitHub repository (repository root must contain `render.yaml`).
2. In Render, choose **New → Blueprint**, connect that repository, and select `render.yaml`.
3. When prompted, supply `ADMIN_PASSWORD` and `PAYMENT_ENCRYPTION_KEY` as secrets. Generate a unique admin password. Generate the encryption key locally with:

   ```bash
   node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
   ```

   The encryption key must be exactly 64 hexadecimal characters. Store a secure backup; losing it makes encrypted gateway keys unreadable.
4. Review the paid Starter service and persistent disk charges, then approve creation/deployment.
5. When the deployment is live, verify `https://YOUR-SERVICE.onrender.com/api/health` and open `https://YOUR-SERVICE.onrender.com/admin`.
6. Sign in with the configured admin email and password. Add Paystack/Flutterwave secret keys only inside the authenticated admin Payment & Referral Settings page.
7. Configure provider webhooks to:
   - `https://YOUR-SERVICE.onrender.com/api/webhooks/paystack`
   - `https://YOUR-SERVICE.onrender.com/api/webhooks/flutterwave`

## Before accepting real money
- Use provider test credentials and test successful, failed, replayed, and mismatched-amount webhook events.
- Confirm the referral commission posts once only after provider verification.
- Confirm database backups and recovery procedures.
- Confirm your merchant accounts support the selected currency and region.
- Complete security, privacy, terms, and compliance review.

## Limitations
This deploys the API and admin dashboard only. It does not compile or publish the Android APK. The Android app's API base URL must be set to the deployed service URL and then rebuilt/signed separately.
