# DisEarn Native Android + Full-Stack Backend

This is a connected native Android + backend development project. The Android app uses Kotlin/Jetpack Compose and Retrofit; the backend uses Node.js/Express and SQLite. It is not a WebView application.

## Package contents
- `android/` — native Android Studio project (Kotlin + Jetpack Compose).
- `backend/` — REST API, SQLite persistence, JWT authentication, bcrypt password hashing, task/submission/skills/wallet/withdrawal endpoints, registration payments and referral commission settlement.
- `backend/public/admin.html` — administrator console with user, task, submission, withdrawal, skills, wallet and Payment & Referral Settings sections.
- `android-integration/DisEarnApi.kt` — Retrofit API contract starter.
- `ADMIN-SETUP.txt` — secure deployment and payment-provider setup.

## Run backend
Requires Node.js 20+.
1. `cd backend && npm install`
2. Copy `.env.example` to `.env`.
3. Configure `JWT_SECRET`, `ADMIN_EMAIL`, `ADMIN_PASSWORD`, and `PAYMENT_ENCRYPTION_KEY`.
4. `npm start`
5. Open `http://localhost:8080/admin`.

The initial registration fee defaults to NGN 10,000 and the referral percentage defaults to 30%; both are editable after admin login. Do not assume the default fee is a final business decision. Configure real provider keys in the admin dashboard.

## Payment and referrals
The API supports Paystack and Flutterwave checkout initialization. Provider webhooks must be configured as described in `ADMIN-SETUP.txt`. A referred user is marked paid only after a provider-verified successful payment. The inviter receives the configured percentage of the actual registration fee, once. Unpaid/failed registrations receive no commission.

Gateway secret keys are write-only in the admin UI and encrypted at rest using AES-256-GCM. The 32-byte encryption key is supplied separately through `PAYMENT_ENCRYPTION_KEY`; never commit it or store it in the database.

## Android status
The Android app now includes registration/login, persistent session token, registration checkout launch and payment-status check, tasks and proof submission, wallet history, referral overview and skills list. Configure `DISearn_API_URL` in `android/gradle.properties` to the deployed HTTPS API origin before building. Open `android/` in Android Studio and build with Android SDK 35 and a compatible JDK. This source package does not include a signed release APK.

## Android API URL
Create `android/gradle.properties` (or add the property to your existing file) and set:
`DISearn_API_URL=https://YOUR-DEPLOYED-API-DOMAIN/`
The app intentionally refuses non-HTTPS API URLs for live use.

## Production checklist
Use HTTPS, production secrets manager, provider test-mode validation, webhook replay/idempotency tests, database backups, monitoring, rate limiting, email verification, password reset, privacy policy/terms, reconciliation, customer support and independent security review. Do not use real customer funds until those steps are complete.
