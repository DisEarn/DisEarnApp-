package com.disearn.app.data

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*

data class LoginRequest(val email: String, val password: String)
data class RegisterRequest(val name: String, val email: String, val password: String, val referralCode: String? = null)
data class AuthUser(val id: Int, val name: String, val email: String, val role: String, val referralCode: String, val status: String, val paymentStatus: String)
data class AuthResponse(val token: String, val user: AuthUser, val balance: Double)
data class TaskItem(val id: Int, val title: String, val platform: String, val description: String, val reward: Double, val instructions: String)
data class SkillItem(val id: Int, val title: String, val description: String, val content_url: String)
data class WalletTransaction(val id: Int, val amount: Double, val type: String, val description: String, val created_at: String)
data class WalletResponse(val balance: Double, val transactions: List<WalletTransaction>)
data class SubmissionRequest(val proof: String)
data class WithdrawalRequest(val amount: Double, val method: String, val destination: String)
data class WithdrawalResult(val id: Int, val status: String, val message: String)
data class PaymentSettings(val registrationFee: Double, val currency: String, val gateway: String, val referralPercent: Double)
data class PaymentInitRequest(val provider: String)
data class PaymentInitResponse(val reference: String?, val provider: String?, val amount: Double?, val currency: String?, val checkoutUrl: String?, val paid: Boolean = false, val message: String? = null)
data class PaymentStatus(val reference: String, val provider: String, val amount: Double, val currency: String, val status: String, val checkout_url: String?)
data class ReferralResponse(val referralCode: String, val referrals: List<ReferralUser>, val commissionEarned: Double)
data class ReferralUser(val name: String, val created_at: String, val payment_status: String)
data class BasicMessage(val message: String)

interface DisEarnApi {
    @POST("api/auth/register") suspend fun register(@Body body: RegisterRequest): AuthResponse
    @POST("api/auth/login") suspend fun login(@Body body: LoginRequest): AuthResponse
    @GET("api/me") suspend fun me(@Header("Authorization") bearer: String): AuthUser
    @GET("api/tasks") suspend fun tasks(@Header("Authorization") bearer: String): List<TaskItem>
    @POST("api/tasks/{id}/submit") suspend fun submitTask(@Header("Authorization") bearer: String, @Path("id") id: Int, @Body body: SubmissionRequest): BasicMessage
    @GET("api/skills") suspend fun skills(@Header("Authorization") bearer: String): List<SkillItem>
    @GET("api/wallet") suspend fun wallet(@Header("Authorization") bearer: String): WalletResponse
    @POST("api/withdrawals") suspend fun withdraw(@Header("Authorization") bearer: String, @Body body: WithdrawalRequest): WithdrawalResult
    @GET("api/referrals") suspend fun referrals(@Header("Authorization") bearer: String): ReferralResponse
    @GET("api/payments/settings") suspend fun paymentSettings(@Header("Authorization") bearer: String): PaymentSettings
    @POST("api/payments/initialize") suspend fun initializePayment(@Header("Authorization") bearer: String, @Body body: PaymentInitRequest): PaymentInitResponse
    @GET("api/payments/status/{reference}") suspend fun paymentStatus(@Header("Authorization") bearer: String, @Path("reference") reference: String): PaymentStatus
}

object DisEarnApiFactory {
    fun create(baseUrl: String): DisEarnApi {
        require(baseUrl.startsWith("https://") && !baseUrl.contains("YOUR_API")) {
            "Set DISearn_API_URL to your deployed HTTPS API URL in android/gradle.properties."
        }
        return Retrofit.Builder().baseUrl(if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/")
            .addConverterFactory(GsonConverterFactory.create()).build().create(DisEarnApi::class.java)
    }
}
